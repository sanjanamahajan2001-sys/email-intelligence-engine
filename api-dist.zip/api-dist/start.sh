#!/bin/bash
./email-api
